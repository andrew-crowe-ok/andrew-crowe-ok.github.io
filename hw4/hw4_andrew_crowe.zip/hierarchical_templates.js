// ==========================================
// 1. HTML UI CONTROLS TEMPLATE (for index.html body)
// ==========================================
/*
<div>
  <b>Hierarchy Controls</b><br>
  <label>Joint 1: <input type="range" id="joint1" min="-180" max="180" step="1" value="0"></label><br>
  <label>Joint 2: <input type="range" id="joint2" min="-180" max="180" step="1" value="0"></label><br>
  <label>Joint 3: <input type="range" id="joint3" min="-180" max="180" step="1" value="0"></label><br>
  <label>End Effector: <input type="range" id="joint4" min="-180" max="180" step="1" value="0"></label><br>
</div>
*/


// ==========================================
// 2. MATRIX STACK IMPLEMENTATION
// ==========================================

const matrixStack = [];

function pushMatrix(m) {
  matrixStack.push(new Float32Array(m));
}

function popMatrix() {
  if (matrixStack.length === 0) {
    throw new Error("Matrix stack underflow");
  }
  return matrixStack.pop();
}


// ==========================================
// 3. GENERIC DRAW HELPER
// ==========================================

// Renders a mesh buffer with a given model transformation matrix
function drawPrimitive(buffers, modelMatrix) {
  // Send current accumulated transform matrix to the vertex shader
  gl.uniformMatrix4fv(uMTM, false, modelMatrix);

  // Bind vertex position buffer and link to shader attribute
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.vbo);
  gl.enableVertexAttribArray(posLoc);
  gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 0, 0);

  // Bind vertex color buffer and link to shader attribute
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.nbo);
  gl.enableVertexAttribArray(colorLoc);
  gl.vertexAttribPointer(colorLoc, 3, gl.FLOAT, false, 0, 0);

  // Bind index buffer and render geometry triangles
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.ibo);
  gl.drawElements(gl.TRIANGLES, buffers.indexCount, gl.UNSIGNED_SHORT, 0);
}


// ==========================================
// 4. HIERARCHICAL RENDERING TEMPLATE (MATRIX STACK)
// ==========================================

function renderHierarchyTemplate() {
  // Read UI parameters
  const angle1 = parseFloat(document.getElementById("joint1").value) * Math.PI / 180.0;
  const angle2 = parseFloat(document.getElementById("joint2").value) * Math.PI / 180.0;
  const angle3 = parseFloat(document.getElementById("joint3").value) * Math.PI / 180.0;

  // Level 1: Root / Base
  let model = mat4Identity();
  model = mat4Translate(model, [0.0, 0.0, 0.0]);
  model = mat4RotateY(model, angle1);

  pushMatrix(model);
  {
    // Draw Root
    let current = mat4Scale(model, [1.0, 1.0, 1.0]);
    drawPrimitive(baseBuffers, current);
  }
  model = popMatrix();

  // Level 2: Child
  model = mat4Translate(model, [0.0, 1.5, 0.0]);
  model = mat4RotateX(model, angle2);

  pushMatrix(model);
  {
    // Draw Level 2
    let current = mat4Scale(model, [0.8, 1.2, 0.8]);
    drawPrimitive(childBuffers, current);
  }
  model = popMatrix();

  // Level 3: Grandchild
  model = mat4Translate(model, [0.0, 1.5, 0.0]);
  model = mat4RotateY(model, angle3);

  pushMatrix(model);
  {
    // Draw Level 3
    let current = mat4Scale(model, [0.6, 1.0, 0.6]);
    drawPrimitive(grandChildBuffers, current);
  }
  model = popMatrix();

  // Level 4: Great-grandchild / End-effector (supports branching)
  pushMatrix(model);
  {
    // Branch A
    let branchA = mat4Translate(model, [0.3, 1.0, 0.0]);
    branchA = mat4Scale(branchA, [0.3, 0.5, 0.3]);
    drawPrimitive(endEffectorBuffers, branchA);
  }
  model = popMatrix();

  pushMatrix(model);
  {
    // Branch B
    let branchB = mat4Translate(model, [-0.3, 1.0, 0.0]);
    branchB = mat4Scale(branchB, [0.3, 0.5, 0.3]);
    drawPrimitive(endEffectorBuffers, branchB);
  }
  model = popMatrix();
}


// ==========================================
// 5. SCENE GRAPH NODE TEMPLATE (ALTERNATIVE OBJECT-BASED)
// ==========================================

class HierarchyNode {
  constructor(buffers, localTransform = mat4Identity()) {
    this.buffers = buffers;
    this.localTransform = localTransform;
    this.children = [];
  }

  addChild(childNode) {
    this.children.push(childNode);
    return childNode;
  }

  draw(parentMatrix = mat4Identity()) {
    const globalMatrix = multiplyMat4(parentMatrix, this.localTransform);

    if (this.buffers) {
      drawPrimitive(this.buffers, globalMatrix);
    }

    for (const child of this.children) {
      child.draw(globalMatrix);
    }
  }
}

